Please download the data folder from this link and keep the folder structure found in the Google drive folder prior to running run.sh on our code.

https://drive.google.com/drive/folders/0B7zjwTQKHJEjRFk1QzQwUkdNemM?usp=sharing